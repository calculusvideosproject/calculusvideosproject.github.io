---
output:
#  html_document: default
  pdf_document: default
## put rmarkdown::render("this_file.Rmd") at the R command line to compile
---




Question
========
The rate at which an office building consumes energy (in kilowatt-hours(KWh) per week) is approximated by $f(t) = 31.461e^{0.7512t}$, where $t$ is in weeks since February 3, 2020. Energy consumption costs 18 cents per kilowatt-hour. 

Use three digit accuracy in all computations.

Select each of the true statements from the following:

Answerlist
----------
* The rate at which energy is consumed 2 weeks after February 3, 2020 is $f(3)$.
* The rate at which energy is consumed 4 weeks after February 3, 2020 is $f(31.461)$.
* The total amount of energy used by the office building during the 3 weeks after February 3, 2020 is $\int_{0}^{3} f(t)dt$.
* An antiderivative of $f(t) = 31.461e^{0.7512t}$ is $F(t) = 41.881e^{0.7512t}$
* $\int_{0}^{3} f(t)dt = 31.461e^{0.7512(3)}-31.461e^{0.7512(0)}$
* The total amount of energy used by the office building during the 4 weeks after February 3, 2020 is 845.25 KWh.
* The energy cost for the office building during the 3 weeks after February 3, 2020 is $64.24.
* All of the above statements are false.


Solution
========

Answerlist
----------
* False. The rate at which energy is consumed 2 weeks after February 3, 2020 is $f(2) =$ 141.337 KWh per week.
* False. The rate at which energy is consumed 4 weeks after February 3, 2020 is $f(4) =$ 634.952 KWh per week.
* True. The total amount of energy used by the office building during the 3 weeks after February 3, 2020 is $$\int_{0}^{3} 31.461e^{0.7512t}dt = \frac{31.461}{0.7512}e^{0.7512(3)}-\frac{31.461}{0.7512}e^{0.7512(0)}=356.908 $$.
* True. An antiderivative of $f(t) = 31.461e^{0.7512t}$ is $F(t) = \frac{31.461}{0.7512}e^{0.7512t}=41.881e^{0.7512t}$
* False. $$\int_{0}^{3} f(t)dt=\int_{0}^{3} 31.461e^{0.7512t}dt = \frac{31.461}{0.7512}e^{0.7512(3)}-\frac{31.461}{0.7512}e^{0.7512(0)}$$.
* False. The total amount of energy used by the office building during the 4 weeks after February 3, 2020 is $$\int_{0}^{4} 31.461e^{0.7512t}dt = \frac{31.461}{0.7512}e^{0.7512(4)}-\frac{31.461}{0.7512}e^{0.7512(0)}=803.369 \text{ KWh}$$.
* True. The total amount of energy used by the office building during the 3 weeks after February 3, 2020 is $$\int_{0}^{3} 31.461e^{0.7512t}dt = \frac{31.461}{0.7512}e^{0.7512(3)}-\frac{31.461}{0.7512}e^{0.7512(0)}=356.908 \text{ KWh}$$ To find the energy cost during this period of time we simply multiply this total amount of energy by 0.18 dollars per KWh to get $64.24
* False. 

Meta-information
================
extype: mchoice
exsolution: 00110010
exname: FTC
