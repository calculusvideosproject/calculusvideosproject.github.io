library(exams)
# setwd("~/src/hack/R/exams/myex/ch02")
exnam<-"chainrule"
tdes<-""
tins<-paste(tdes," For each question, select all statements that are true.  
You have an unlimited number of attempts. Only the highest score will 
be recorded in the gradebook.
After submission, the answers for each question will be displayed and explanations 
for each answer can be obtained by clicking the \"View Feedback\" link after 
each question. ")
myexam<-list(
  "chainrule.Rmd",
  "chainrule.Rmd"
)
exams2blackboard(myexam,
                 n=30,base64=TRUE,
                 name=exnam,
                 dir=".",
                 edir=".",
                 tdescription=tins,tinstruction=tdes,
                 maxattempts=Inf)