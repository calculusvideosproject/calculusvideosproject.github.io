library(exams)
# setwd("~/src/hack/R/exams/myex/ch02")
exnam<-"AverageRateOfChange"
tdes<-""
tins<-paste(tdes," For each question, select all statements that are true.  
You have up to three attempts. Only the score from your last attempt will 
be recorded in the gradebook.
After submission, the answers for each question will be displayed and explanations 
for each answer can be obtained by clicking the \"View Feedback\" link after 
each question. ")
myexam<-list(
  "AverageCarSpeed.Rmd",
  "AverageCarSpeed.Rmd",
  "AverageVelocity.Rmd",
  "AverageVelocity.Rmd"
)
exams2blackboard(myexam,
                 n=5,base64=TRUE,
                 name=exnam,
                 dir=".",
                 edir=".",
                 tdescription=tins,tinstruction=tdes,
                 maxattempts=Inf)