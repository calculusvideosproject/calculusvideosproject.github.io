library(exams)
# setwd("~/src/hack/R/exams/myex/ch02")
tdes<-"These are problems on the concept of small multiples plots 
of dot plots from section 4 of Chapter 2."
tins<-paste(tdes," For each question, select all statements that are true.  
You can try these problems as often as you like.  The grade recorded will 
be your highest score (not your last score, so you don't need to stress 
about trying again for review purposes once you have a grade you want to keep).  
After submission, the answers for each question will be displayed and solutions 
for each question can be obtained by clicking the \"View Feedback\" link after 
each question. If your score is not 100%, please review these solutions in order 
to learn from your mistakes and then try again.")
myexam<-list(
  "ConstantRateOfChange.Rmd",
  "ConstantRateOfChange.Rmd"
)
exams2blackboard(myexam,
                 n=5,base64=TRUE,
                 name="ConstantRateOfChange",
                 dir=".",
                 edir=".",
                 tdescription=tins,tinstruction=tdes,maxattempts=Inf)